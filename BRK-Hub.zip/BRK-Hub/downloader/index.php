<?php
// BRK Hub - Multi Downloader UI (v1)

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BRK Hub - Downloader</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body {
            font-family: Arial;
            background: #0f172a;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box {
            width: 420px;
            background: #111827;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }

        h2 {
            text-align: center;
            margin-bottom: 15px;
        }

        input, select, button {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            border-radius: 8px;
            border: none;
            font-size: 14px;
        }

        input {
            background: #1f2937;
            color: #fff;
        }

        select {
            background: #1f2937;
            color: #fff;
        }

        button {
            background: #2563eb;
            color: white;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background: #1d4ed8;
        }

        .result {
            margin-top: 15px;
            padding: 10px;
            background: #1f2937;
            border-radius: 8px;
            display: none;
        }
    </style>
</head>

<body>

<div class="box">
    <h2>BRK Hub Downloader</h2>

    <select id="platform">
        <option value="auto">Auto Detect</option>
        <option value="youtube">YouTube</option>
        <option value="instagram">Instagram</option>
        <option value="facebook">Facebook</option>
        <option value="tiktok">TikTok</option>
    </select>

    <input type="text" id="url" placeholder="Paste video link here...">

    <button onclick="processDownload()">Download</button>

    <div class="result" id="resultBox"></div>
</div>

<script>
function processDownload() {
    let url = document.getElementById("url").value;
    let platform = document.getElementById("platform").value;

    let resultBox = document.getElementById("resultBox");

    if(url === "") {
        alert("Please enter a URL");
        return;
    }

    resultBox.style.display = "block";
    resultBox.innerHTML = "Processing download request...";

    fetch("handler.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "url=" + encodeURIComponent(url) + "&platform=" + platform
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === "success") {
            resultBox.innerHTML = "✅ Download Ready:<br><a href='" + data.download_url + "' target='_blank'>Click to Download</a>";
        } else {
            resultBox.innerHTML = "❌ " + data.message;
        }
    })
    .catch(err => {
        resultBox.innerHTML = "❌ Server Error";
    });
}
</script>

</body>
</html>